<html>
    <head>
        <title>Upload Image</title>
    </head>
    <body>
        <form action="process_upload.php" method="POST" enctype="multipart/form-data">

        <label for=
    </body>

</html>